using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using LiveCharts;
using LiveCharts.Wpf;

namespace WeatherStation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // folder paths for the two weather stations
        private string SherkinFolder = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "SherkinWeatherData");

        private string RochesFolder = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "RochesWeatherData");

        // stores the selected parameter file path for each station
        private string _sherkinParamFile = "";
        private string _rochesParamFile = "";

        // key/value pair storage for the extracted weather data
        private SortedDictionary<DateTime, double> _sherkinData = new SortedDictionary<DateTime, double>();
        private SortedDictionary<DateTime, double> _rochesData = new SortedDictionary<DateTime, double>();

        // labels for x-axis on both charts
        public List<string> PlotLabels { get; set; } = new List<string>();
        public List<string> RangeLabels { get; set; } = new List<string>();

        public MainWindow()
        {
            InitializeComponent();
        }

        // Load Data button click handler
        private void BtnLoadData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // reset everything when loading fresh data
                _sherkinParamFile = "";
                _rochesParamFile = "";
                TxtSherkinParam.Text = "";
                TxtRochesParam.Text = "";
                _sherkinData.Clear();
                _rochesData.Clear();

                // IsEnabled greys out controls until they are needed
                // https://learn.microsoft.com/en-us/dotnet/api/system.windows.uielement.isenabled
                BtnPlot.IsEnabled = false;
                MenuPlotStations.IsEnabled = false;
                BtnRange.IsEnabled = false;
                SldCount.IsEnabled = false;
                MenuWriteDiff.IsEnabled = false;
                TxtCount.Text = "";
                TxtCountRange.Text = "";

                ChartPlot.Series = null;
                ChartRange.Series = null;
                TxtPlotTitle.Text = "Parameter Chart";
                TxtRangeTitle.Text = "Range Chart";

                LoadStation(SherkinFolder, LstSherkin, "Sherkin");
                LoadStation(RochesFolder, LstRoches, "Roches");
                TxtStatus.Text = "Data loaded.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data folders:\n" + ex.Message,
                    "Load Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // scans a folder and populates the listbox with parameter file names (skipping Time)
        private void LoadStation(string folder, ListBox listBox, string stationPrefix)
        {
            if (!Directory.Exists(folder))
            {
                MessageBox.Show("Folder not found:\n" + folder,
                    "Missing Folder", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            listBox.Items.Clear();

            // get all txt files in the station folder
            string[] files = Directory.GetFiles(folder, "*.txt");

            for (int i = 0; i < files.Length; i++)
            {
                string fileName = Path.GetFileNameWithoutExtension(files[i]);

                // spec says do not put Time in the listbox
                // EndsWith: https://learn.microsoft.com/en-us/dotnet/api/system.string.endswith
                if (fileName.ToLower().EndsWith("time"))
                    continue;

                // strip the station prefix to get just the parameter name
                string paramName = fileName.Replace(stationPrefix, "").Trim();
                listBox.Items.Add(paramName);
            }
        }

        // Double click handlers for both listboxes
        // MouseDoubleClick: https://learn.microsoft.com/en-us/dotnet/api/system.windows.controls.control.mousedoubleclick
        private void LstSherkin_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (LstSherkin.SelectedItem == null) return;

            string param = LstSherkin.SelectedItem.ToString();
            _sherkinParamFile = Path.Combine(SherkinFolder, "Sherkin " + param + ".txt");
            TxtSherkinParam.Text = param;

            EnablePlotIfReady();
        }

        private void LstRoches_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (LstRoches.SelectedItem == null) return;

            string param = LstRoches.SelectedItem.ToString();
            _rochesParamFile = Path.Combine(RochesFolder, "Roches " + param + ".txt");
            TxtRochesParam.Text = param;

            EnablePlotIfReady();
        }

        // enables the Plot button once both parameters are selected
        private void EnablePlotIfReady()
        {
            // File.Exists: https://learn.microsoft.com/en-us/dotnet/api/system.io.file.exists
            bool ready = _sherkinParamFile != "" &&
                         _rochesParamFile != "" &&
                         File.Exists(_sherkinParamFile) &&
                         File.Exists(_rochesParamFile);

            BtnPlot.IsEnabled = ready;
            MenuPlotStations.IsEnabled = ready;
        }

        // reads the time file + param file and builds key/value pairs
        private SortedDictionary<DateTime, double> ExtractData(string timeFile, string paramFile)
        {
            SortedDictionary<DateTime, double> result = new SortedDictionary<DateTime, double>();
            StreamReader srTime = null;
            StreamReader srValues = null;

            try
            {
                srTime = new StreamReader(timeFile);
                srValues = new StreamReader(paramFile);

                string timeLine;
                string valueLine;

                // read both files line by line simultaneously
                while ((timeLine = srTime.ReadLine()) != null &&
                       (valueLine = srValues.ReadLine()) != null)
                {
                    // use today's date combined with the time from file
                    string dateTimeStr = DateTime.Today.ToString("yyyy-MM-dd") + " " + timeLine.Trim();

                    try
                    {
                        DateTime dt = DateTime.Parse(dateTimeStr);
                        double val = Convert.ToDouble(valueLine.Trim());
                        result[dt] = val;
                    }
                    catch (FormatException)
                    {
                        // skip lines that have bad format
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File not found:\n" + ex.Message,
                    "Missing File", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading data:\n" + ex.Message,
                    "Read Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                // always close the readers even if exception occurred
                if (srTime != null) srTime.Close();
                if (srValues != null) srValues.Close();
            }

            return result;
        }

        // Plot button handler
        private void BtnPlot_Click(object sender, RoutedEventArgs e)
        {
            if (_sherkinParamFile == "" || _rochesParamFile == "")
            {
                MessageBox.Show("Please double-click a parameter in each ListBox before plotting.",
                    "No Parameter Selected", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // check that both stations have the same parameter selected
            if (TxtSherkinParam.Text.ToLower() != TxtRochesParam.Text.ToLower())
            {
                MessageBox.Show("Please select the same parameter in both listboxes.");
                return;
            }

            try
            {
                string sherkinTimeFile = Path.Combine(SherkinFolder, "Sherkin Time.txt");
                string rochesTimeFile = Path.Combine(RochesFolder, "Roches Time.txt");

                _sherkinData = ExtractData(sherkinTimeFile, _sherkinParamFile);
                _rochesData = ExtractData(rochesTimeFile, _rochesParamFile);

                if (_sherkinData.Count == 0 || _rochesData.Count == 0)
                {
                    TxtStatus.Text = "No data to plot.";
                    return;
                }

                // build x axis labels from the sherkin times
                PlotLabels.Clear();
                foreach (KeyValuePair<DateTime, double> pair in _sherkinData)
                {
                    PlotLabels.Add(pair.Key.ToString("HH:mm"));
                }

                // pull the values out into lists for the chart
                List<double> sherkinValues = new List<double>();
                foreach (KeyValuePair<DateTime, double> pair in _sherkinData)
                {
                    sherkinValues.Add(pair.Value);
                }

                List<double> rochesValues = new List<double>();
                foreach (KeyValuePair<DateTime, double> pair in _rochesData)
                {
                    rochesValues.Add(pair.Value);
                }

                // create two line series, one per station
                LineSeries sherkinSeries = new LineSeries
                {
                    Title = "Sherkin Island",
                    Values = new ChartValues<double>(sherkinValues),
                    PointGeometrySize = 6,
                    StrokeThickness = 2
                };

                LineSeries rochesSeries = new LineSeries
                {
                    Title = "Roches Point",
                    Values = new ChartValues<double>(rochesValues),
                    PointGeometrySize = 6,
                    StrokeThickness = 2
                };

                ChartPlot.Series = new SeriesCollection { sherkinSeries, rochesSeries };

                // set the labels on the x axis
                if (ChartPlot.AxisX.Count > 0)
                    ChartPlot.AxisX[0].Labels = PlotLabels;

                string paramName = TxtSherkinParam.Text;
                TxtPlotTitle.Text = "Parameter Chart - " + paramName;
                TxtStatus.Text = "Plotted " + _sherkinData.Count + " readings for " + paramName + ".";

                // use whichever station has fewer readings as the max for the slider
                int maxElement = _sherkinData.Count;
                if (_rochesData.Count < maxElement)
                    maxElement = _rochesData.Count;

                SldCount.Minimum = 1;
                SldCount.Maximum = maxElement;
                SldCount.Value = 1;
                SldCount.IsEnabled = true;
                TxtCount.Text = "1";
                TxtCountRange.Text = "1 to " + maxElement;

                BtnRange.IsEnabled = true;
                MenuWriteDiff.IsEnabled = true;

                // write the differences file straight away after plotting
                WriteDifferencesFile();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error plotting data:\n" + ex.Message,
                    "Plot Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Slider ValueChanged
        private void SldCount_ValueChanged(object sender,
            RoutedPropertyChangedEventArgs<double> e)
        {
            // this can fire during InitializeComponent before TxtCount exists
            if (TxtCount == null) return;

            int count = (int)SldCount.Value;
            TxtCount.Text = count.ToString();
        }

        // Range button handler
        private void BtnRange_Click(object sender, RoutedEventArgs e)
        {
            if (_sherkinData.Count == 0 || _rochesData.Count == 0)
            {
                MessageBox.Show("No data available. Plot data first.",
                    "No Data", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int count = (int)SldCount.Value;

                // grab the first 'count' items from each sorted dictionary
                List<DateTime> sherkinKeys = new List<DateTime>();
                List<double> sherkinValues = new List<double>();
                int n = 0;
                foreach (KeyValuePair<DateTime, double> pair in _sherkinData)
                {
                    if (n >= count) break;
                    sherkinKeys.Add(pair.Key);
                    sherkinValues.Add(pair.Value);
                    n++;
                }

                List<double> rochesValues = new List<double>();
                n = 0;
                foreach (KeyValuePair<DateTime, double> pair in _rochesData)
                {
                    if (n >= count) break;
                    rochesValues.Add(pair.Value);
                    n++;
                }

                // build labels for this subset
                RangeLabels.Clear();
                for (int i = 0; i < sherkinKeys.Count; i++)
                {
                    RangeLabels.Add(sherkinKeys[i].ToString("HH:mm"));
                }

                LineSeries sherkinRange = new LineSeries
                {
                    Title = "Sherkin Island",
                    Values = new ChartValues<double>(sherkinValues),
                    PointGeometrySize = 6,
                    StrokeThickness = 2
                };

                LineSeries rochesRange = new LineSeries
                {
                    Title = "Roches Point",
                    Values = new ChartValues<double>(rochesValues),
                    PointGeometrySize = 6,
                    StrokeThickness = 2
                };

                ChartRange.Series = new SeriesCollection { sherkinRange, rochesRange };

                if (ChartRange.AxisX.Count > 0)
                    ChartRange.AxisX[0].Labels = RangeLabels;

                string paramName = TxtSherkinParam.Text;
                TxtRangeTitle.Text = "Range Chart - " + paramName + " (first " + count + " readings)";
                TxtStatus.Text = "Range: showing " + count + " of " + _sherkinData.Count + " readings.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error displaying range:\n" + ex.Message,
                    "Range Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Write differences to file
        private void WriteDifferencesFile()
        {
            StreamWriter sw = null;

            try
            {
                // find timestamps that exist in both datasets
                List<DateTime> commonKeys = new List<DateTime>();
                foreach (KeyValuePair<DateTime, double> pair in _sherkinData)
                {
                    if (_rochesData.ContainsKey(pair.Key))
                    {
                        commonKeys.Add(pair.Key);
                    }
                }

                if (commonKeys.Count == 0)
                {
                    TxtStatus.Text = "No matching timestamps to compute differences.";
                    return;
                }

                string paramName = TxtSherkinParam.Text;
                string diffFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                    paramName + "_Differences.txt");

                sw = new StreamWriter(diffFile);

                // header line
                sw.WriteLine("DateTime\tSherkin\tRoches\tDifference");

                for (int i = 0; i < commonKeys.Count; i++)
                {
                    DateTime key = commonKeys[i];
                    double sVal = _sherkinData[key];
                    double rVal = _rochesData[key];
                    double diff = sVal - rVal;

                    sw.WriteLine(key.ToString("yyyy-MM-dd HH:mm") + "\t" +
                        sVal + "\t" + rVal + "\t" + diff.ToString("F2"));
                }

                TxtStatus.Text = "Differences written to " + Path.GetFileName(diffFile) + ".";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error writing differences:\n" + ex.Message,
                    "Write Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (sw != null) sw.Close();
            }
        }

        // menu handler for write differences
        private void MenuWriteDiff_Click(object sender, RoutedEventArgs e)
        {
            WriteDifferencesFile();
        }

        // Exit handler
        // Application.Current.Shutdown: https://learn.microsoft.com/en-us/dotnet/api/system.windows.application.shutdown
        private void MenuExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
